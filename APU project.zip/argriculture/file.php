<?php

echo "printed data from server";